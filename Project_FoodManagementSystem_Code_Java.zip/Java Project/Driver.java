import java.io.*;
import java.util.*;
public class Driver 
{
    public static void main(String[] args) throws InterruptedException, IOException
    {
        StudentLoginAndRegister.register();
        Customer.showCustomers();
        Inventory.config();
        Inventory.showRediInventory();
        StudentActivities.takeOrders();
        StudentActivities.showOrder();
        StudentActivities.placeOrder();
        Inventory.showRediInventory();
        AdminActivities.getInsights();
    }
}