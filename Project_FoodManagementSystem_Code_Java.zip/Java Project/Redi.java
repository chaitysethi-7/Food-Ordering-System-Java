import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
public class Redi 
{
    private String rediName;
    ArrayList<CustomPair> inventory;
    ArrayList<CustomPair> inventorySold;
    private int totalRevenue;
    Redi(String name)
    {
        this.rediName = name;
        this.inventory = new ArrayList<CustomPair>();
        this.inventorySold  = new ArrayList<CustomPair>();
        this.totalRevenue = 0;
    }
    public String getRediName()
    {
        return this.rediName;
    }
    public void addItem(Item item, int quantity)
    {
        inventory.add(new CustomPair(item,quantity));
        inventorySold.add(new CustomPair(item,0));
    }
    public void removeItem(String itemId)
    {
        CustomPair remove = null;
        for(CustomPair e : inventory)
        {
            
            if(e.getItemId().equalsIgnoreCase(itemId))
            {
                remove = e;
                break;
            }
        }
        inventory.remove(remove);
        
    }
    public void placeOrder(Student obj, String itemId, int quantity)
    {
        for(CustomPair e : inventory)
        {
            if(e.getItemId().equals(itemId) && quantity <= e.getQuantity() )
            {
                obj.updateItem(e.getItem(), quantity, getRediName());
                e.setQuantity(e.getQuantity()-quantity);
                totalRevenue += e.getPrice()*quantity;
                for(CustomPair f : inventorySold)
                {
                    if(f.getItemId().equals(itemId))
                    {
                        f.setQuantity(f.getQuantity()+quantity);
                        break;
                    }
                }
            }
        }
    }
    public void showInventory() throws IOException
    {
        FileWriter fw = new FileWriter("Final Inventory.txt",true);
        for(CustomPair e : inventory)
        {
            System.out.println(e.getItem()+ " " +  "Quantity : " + e.getQuantity());
            fw.write(e.getItem()+ " " +  "Quantity : " + e.getQuantity()+"\n");
        }
    }
    public int getTotalRevenue()
    {
        return totalRevenue;
    }
    public CustomPair getMaxSoldItem()
    {
        Collections.sort(inventorySold);
        return  inventorySold.get(inventorySold.size()-1);
    }
}
