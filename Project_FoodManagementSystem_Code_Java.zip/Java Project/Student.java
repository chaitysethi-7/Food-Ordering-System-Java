import java.io.*;
import java.util.*;
public class Student 
{
    private String name;
    private String bitsId;
    private String emailId;
    private String phoneNo;
    private int totalAmountSpent;
    private int monthlyExpense;
    private HashMap<String,ArrayList<CustomPair>> itemsBought;
    Student(String name, String bitsId, String emailId, String phoneNo)
    {
        this.name = name;
        this.bitsId = bitsId;
        this.emailId = emailId;
        this.phoneNo = phoneNo;
        this.totalAmountSpent = 0;
        this.monthlyExpense = 0;
        itemsBought = new HashMap<>();
        itemsBought.put("Shankar",new ArrayList<>());
        itemsBought.put("Meera",new ArrayList<>());
        itemsBought.put("CVR",new ArrayList<>());
        itemsBought.put("SR",new ArrayList<>());
    }
    public String getName()
    {
        return this.name;
    }
    public String getBitsId()
    {
        return this.bitsId;
    }
    public String getEmailId()
    {
        return this.emailId;
    }
    public String getPhoneNo()
    {
        return this.phoneNo;
    }
    public void generateOrderHistory()
    {
        System.out.println("Order History for " + name + " Bits Id : " + bitsId);
        System.out.println("Food Items Ordered");
        for(Map.Entry<String,ArrayList<CustomPair>> e : itemsBought.entrySet())
        {
            System.out.println("Items ordered at Redi " + e.getKey());
            if(e.getValue().size() == 0)
                System.out.println("None");
            for(CustomPair i : e.getValue())
            {
                System.out.print("Description: " + i.getItem() + " Quantity: "  + i.getQuantity());
                System.out.println();
            }
            
        }
        System.out.println("Total Expenses :" + this.totalAmountSpent);
        System.out.println("Monthly Expenses: "+ this.monthlyExpense);
    }
    public void updateItem(Item item, int quantity, String rediName)
    {
        boolean flag = false;
        for(Map.Entry<String,ArrayList<CustomPair>> e : itemsBought.entrySet())
        {
            if (e.getKey().equals(rediName))
            {
                for(CustomPair i : e.getValue())
                {
                    if(i.getItem() == item )
                    {
                        i.setQuantity(i.getQuantity() + quantity);
                        flag = true;
                        break;
                    }
                }
            }
            
        }
        if(!flag)
        {
            itemsBought.get(rediName).add(new CustomPair(item,quantity));
        }
        totalAmountSpent += item.getItemPrice()* quantity;
        monthlyExpense += item.getItemPrice()* quantity;
    }
    public void resetMonthlyexp()
    {
        this.monthlyExpense = 0; 
    }
    
}
